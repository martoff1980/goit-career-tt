import styled from 'styled-components'
const Wrap = styled.div`padding:40px; text-align:center; color: #6b7280;`
export default function Loader(){ return <Wrap>Loading...</Wrap> }
